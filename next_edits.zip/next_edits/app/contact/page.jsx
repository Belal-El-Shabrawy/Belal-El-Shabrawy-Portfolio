'use client';

import dynamic from 'next/dynamic';

// Contact also renders a <Canvas> (the Fox model), so it needs the same
// ssr: false treatment as Home to avoid WebGL SSR errors.
const Contact = dynamic(() => import('@/components/Contact'), { ssr: false });

export default function ContactPage() {
  return <Contact />;
}
